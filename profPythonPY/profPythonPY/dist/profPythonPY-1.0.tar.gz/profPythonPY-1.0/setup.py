from setuptools import setup, find_packages

setup(
    name='profPythonPY',
    version='1.0',
    description='Python code pour doc. LaTeX',
    url='https://twitter.com/davidequantique',
    author='David COBAC',
    author_email='david.cobac@gmail.com',
    license='CC-BY-NC-SA',
    packages=find_packages()
)
